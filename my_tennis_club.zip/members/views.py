from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from .models import Member
from django.db.models import Q
# Create your views here.

def members(request):
    mymembers = Member.objects.all().values()
    template = loader.get_template('all_members.html')
    context={
        'mymembers':mymembers,
    }
    return HttpResponse(template.render(context,request))

def details(request,slug):
    mymember = Member.objects.get(slug=slug)
    template = loader.get_template('details.html')
    context={
        'mymember': mymember,
    }
    return HttpResponse(template.render(context,request))   

def main(request) :
    template = loader.get_template('main.html')
    return HttpResponse(template.render())

def testing(request):
    members  = Member.objects.all().values()
    template= loader.get_template('template.html')
    # context={
    #     'programming_languages':["Python","C","C++","Java"],
    #     'x':["Go","HTML"],
    #     "y":["Go","HTML"],
       
    # }
    context ={
        "members":members
    }
    return HttpResponse(template.render(context,request))
def testing1(request):
    # mydata= Member.objects.filter(firstname__startswith='L')
    #mydata= Member.objects.filter(Q(firstname='Emil')|Q(firstname='Tobias')).values()
    # mydata = Member.objects.filter(firstname='Emil').values() | Member.objects.filter(firstname='Tobias').values()
    # mydata= Member.objects.filter(last_name='Resfnus',id=3).values()
    # mydata= Member.objects.all().order_by('firstname').values()  # ascending order
    # mydata= Member.objects.all().order_by('-firstname').values()  # descending order 
    mydata= Member.objects.all().order_by('last_name','-id').values()

    template= loader.get_template('template1.html')
    context={
        'mymembers':mydata,
    }
    return HttpResponse(template.render(context,request))