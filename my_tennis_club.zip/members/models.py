from django.db import models

# Create your models here.

class Member(models.Model):
    firstname= models.CharField(max_length=250)
    last_name= models.CharField(max_length=250)
    # add two fields later 
    phone= models.IntegerField(null=True) 
    joined_date = models.DateField(null=True)
    slug = models.SlugField(default=" ",null=False)
    # this is the __str__ representation of the members
    # def __str__(self):
    #     return f"{self.firstname} {self.last_name}"