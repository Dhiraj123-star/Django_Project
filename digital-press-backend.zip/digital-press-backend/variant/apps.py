from django.apps import AppConfig


class VariantConfig(AppConfig):
    name = 'variant'
