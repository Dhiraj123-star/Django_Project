from django.apps import AppConfig


class CatalogProductConfig(AppConfig):
    name = 'catalog_product'
