from django.apps import AppConfig


class StudioConfig(AppConfig):
    name = 'studio'
