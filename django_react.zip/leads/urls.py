from django.urls import path
from . import views

urlpatterns = [
    path('api/lead',views.LeadCreateView.as_view()),
]