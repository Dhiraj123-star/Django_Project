from django.urls import path
from .views import upload_resume,upload_images

urlpatterns =[
    path ('upload_resume/',upload_resume,name='files'),
    path('upload_images/',upload_images,name='images'), 
]