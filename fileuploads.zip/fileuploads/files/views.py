from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms  import ResumeForm,ImageForm
from .models import Image
# Create your views here.


def upload_resume(request):

    if request.method =='POST':
        form = ResumeForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()

            return HttpResponseRedirect("/")
    else :
        form = ResumeForm

    return render(request,'files/resume.html',{'form':form})


def upload_images(request):
    if request.method =='GET':
        images = Image.objects.order_by('title')
    return render(request, "files/image.html", {"images": images })



   