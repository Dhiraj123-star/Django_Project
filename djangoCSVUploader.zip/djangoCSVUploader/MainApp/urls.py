# from django.contrib import admin
# from django.urls import path,include
# from rest_framework import routers
# from MainApp.views import *


# router = routers.DefaultRouter()

# # API 

# router.register(r'students',StudentViewSet,basename='students')

# urlpatterns =[

#         path('admin/',admin.site.urls),
        
# ]