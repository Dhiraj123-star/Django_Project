from django.apps import AppConfig


class SlugappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'slugapp'
