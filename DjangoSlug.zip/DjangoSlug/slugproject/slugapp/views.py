from django.shortcuts import render
from slugapp.models import Blog
from django.views.generic import ListView,DetailView

# Create your views here.

class BlogListView(ListView):
    model = Blog
    template_name = 'blog_list.html'
    

class BlogDetailView(DetailView):
    model = Blog
    template_name = 'blog_detail.html'