from django.db import models
from django.urls import reverse
from django.template.defaultfilters import slugify

# Create your models here.

def create_slug(title):
    slug =slugify(title)
    qs = Blog.objects.filter(slug=slug)
    exists = qs.exists()

    if exists:
        slug = "%s-%s" %(slug, qs.first().id)

        return slug


class Blog(models.Model):
    title = models.CharField(max_length=128)
    body = models.TextField()
    slug = models.SlugField(null=True,unique=True,blank=True)

    def __str__(self) :
        return  self.title

    def get_absolute_url(self):
        return reverse('blog_detail',kwargs=[str(self.id)])  
    
    def save(self,*args,**kwargs):
        if not self.slug :
            self.slug = create_slug(self.title)

        return super().save(*args,**kwargs)