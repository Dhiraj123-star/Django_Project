from django.urls import path
from slugapp.views import BlogListView,BlogDetailView

urlpatterns = [

    path('<slug:slug>',BlogDetailView.as_view(),name='blog_detail'),
    path('',BlogListView.as_view(),name='blog_list'),
]