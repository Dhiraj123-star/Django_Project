from django.contrib import admin
from slugapp.models import Blog
# Register your models here.

class BlogAdmin(admin.ModelAdmin):
    list_display=['title','body']
    prepopulated_fields = {'slug':('title',)} 


admin.site.register(Blog,BlogAdmin)
